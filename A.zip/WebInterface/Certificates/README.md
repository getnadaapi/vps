## Generate a self-signed certificate

The following OpenSSL command creates a 4096-bit private key (domain.key) and a self-signed certificate (domain.crt) with an expiration of 10 years (3650 days).

    $ openssl req -newkey rsa:4096 -nodes -keyout domain.key -x509 -days 3650 -out domain.crt -subj '/C=AA/O=den4b Team/CN=shutter.local'

The certificate subject properties are populated through the use of `-subj` command line argument.
