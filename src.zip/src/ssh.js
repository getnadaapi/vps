const { spawn } = require('node-pty')
const { debug } = require('./log')

const ssh = ({
  host,
  user,
  password,
  port,
  bind,
  connectTimeout,
  connectionAttempts,
  knownHostsFile,
  enableDataCompression,
  bin,
}) => {
  if (!String(bind).includes('0.0.0.0')) bind = `0.0.0.0:${bind}`
  const args = [
    [ '-D', bind ],
    port && [ '-p', port ],
    connectTimeout && [ '-o', `ConnectTimeout ${ Math.max(1, Math.ceil(connectTimeout / 1e3) || 0) }` ],
    connectionAttempts && [ '-o', `ConnectionAttempts ${ connectionAttempts }` ],
    knownHostsFile && [ '-o', `UserKnownHostsFile "${ knownHostsFile }"` ],
    enableDataCompression && '-C',
    [ '-o', 'HostkeyAlgorithms +ssh-rsa' ],
    [ '-o', 'StrictHostKeyChecking no' ],
    '-N',
    `${ user }@${ host }`,
  ]
    .flat()
    .filter(Boolean)
    .map(String)

  debug(4)(bin, ...args.map(arg => arg?.includes?.(' ') ? `'${ arg }'` : arg))

  const ssh = spawn(bin, args)

  const listener = ssh.onData(data => {
    if (/'s password:/.test(data)) {
      debug(3)('input password', host)

      ssh.write(`${ password }\r`)

      // remove the listener some time after the successful connection
      setTimeout(() => listener.dispose(), connectTimeout)
    } else if (/(?:can|could)\s?not.+(?:listen.+port|forward)/i.test(data)) {
      debug(2)(data)

      ssh.kill()
    }
  })

  ssh.onExit(() => debug(2)('port', bind, 'connection to', host, 'closed'))

  return ssh
}

module.exports = ssh
