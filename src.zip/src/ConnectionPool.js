const Connection = require('./Connection')
const expired = require('./expired')
const { info, debug } = require('./log')
const ServerList = require('./ServerList')

class ConnectionPool {
  constructor(config) {
    debug(3)('config', config)

    /**
     * @type {import('../config.js')}
     */
    this.config = config
    /**
     * @type {ServerList}
     */
    this.serverList = config.serverList || new ServerList(config)

    this.connections = []
  }

  async connect() {
    debug(4, 'start rotation')

    const { rotateAfter: timeout } = this.config

    const connections = this.connections.filter(({ lastUpdated }) => expired(lastUpdated, timeout))

    if (!connections.length) {
      debug(2, 'redundant call to rotate')

      return
    }

    debug(1)('prepare', connections.length, 'servers')

    connections.forEach(connection => connection.touch())

    const servers = await this.serverList.select(connections.length)

    connections.forEach((connection, i) => connection.setServer(servers[ i ]))

    info('connect', ...connections.map(({ config: { bind }, server: { host } }) => [ bind, host ]).flat())
  }

  rotate() {
    this.connections.forEach(connection => {
      connection.lastUpdated = 0
    })

    this.connect()
  }

  start() {
    const { portRange: [ start, end ], rotateAfter: interval } = this.config

    /**
     * @type {[Connection]}
     */
    this.connections = Array(end - start + 1)
      .fill()
      .map((v, i) => {
        const connection = new Connection({
          ...this.config,
          bind: start + i,
        })

        connection.on('disconnected', () => this.connect())

        return connection
      })

    this.connect()

    setInterval(() => this.rotate(), Math.max(30000, interval))
  }
}

module.exports = ConnectionPool
