const parse = item => {
  const [ host, user, password ] = item.split('|')

  return {
    host,
    user,
    password,
  }
}

module.exports = parse
