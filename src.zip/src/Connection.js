const { debug } = require('./log')
const { EventEmitter } = require('events')
const expired = require('./expired')
const ssh = require('./ssh')

class Connection extends EventEmitter {
  constructor(config) {
    super()

    this.config = config
    this.server = null
    /**
     * @type {import('node-pty').IPty}
     */
    this.process = null
    this.rotating = false
    this.lastUpdated = 0

    this.timer = null
  }

  connect() {
    if (!this.server) {
      throw Error('no server has been set')
    }

    if (this.process) {
      debug(2)('rotate connection on port', this.config.bind)

      this.rotating = true

      return void this.process.kill()
    }

    const process = ssh({ ...this.config, ...this.server })

    this.process = process
    this.rotating = false

    process.onExit(() => {
      this.process = null

      if (this.rotating) {
        this.connect()
      } else {
        this.server = null
        this.lastUpdated = 0

        this.emit('disconnected')
      }
    })
  }

  setServer(server) {
    this.server = server

    this.touch()
    this.connect()
  }

  touch() {
    this.lastUpdated = Date.now()
  }
}

module.exports = Connection
